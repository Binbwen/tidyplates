

----------------------------------
-- Combat Widget				--
----------------------------------
-- Combo Point Widget Redesign. --
----------------------------------



--[[


* Create Widget Carrier Frames for each plate

* Create Single Widget Frame
	- Create 6 dots
	- 

* Update anchor function
* Update power/resource function
* Per-Class Resource Update function
* Start with Druid and Rogue






--]]
